#ifndef LIST_LIST_H
#define LIST_LIST_H

#include <iostream>

template<class T>
struct node {
    node<T>* next;
    T data;
};

template<class T>
class List {
    public:
        node<T> *first;
        node<T> *last;

        List<T>() { first=nullptr; last=nullptr; };
        void add(T data);
        T get(int index);
        T operator [](int index);
};
#endif //LIST_LIST_H